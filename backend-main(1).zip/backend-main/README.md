# Guide to run the backend

## To prepare everything

- add proper configuration to **".env.example"** file and rename it to **".env"**

- run **"npm install"**

## Build and run the app for production

- run **"npm run build"**

- (optional) delete **"src"** directory

- run **"node ."**

## Run in development mode (restart automatically per change)

- run **"npm run dev"**