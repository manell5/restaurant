import { readdirSync } from 'node:fs';
import { join, resolve } from 'node:path';

export default async function importDirectory(
    relativePath: string,
): Promise<void> {
    const directoryPath = resolve(relativePath); // Resolve absolute path
    const files = readdirSync(directoryPath);

    for (const file of files) {
        if (file.endsWith('.js')) {
            const filePath = join(directoryPath, file);
            await import(filePath); // Dynamically import the file
        }
    }
}
