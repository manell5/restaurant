export interface Product {
    id: string;
    nom: string;
    prix: number;
    description: string;
    categorie: string;
    image: string;
    created_at: Date;
}
