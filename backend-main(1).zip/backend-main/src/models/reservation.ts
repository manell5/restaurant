export interface Reservation {
    id: string;
    created_at: Date;
    user_id: string;
    number_of_people: number;
    date: Date;
}