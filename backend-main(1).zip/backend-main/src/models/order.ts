export interface Order {
    id: string;
    created_at: Date;
    user_id: string;
    product_id: string;
    quantity: number;
}
