export interface User {
    id: string;
    nom: string;
    prenom: string;
    email: string;
    password: string;
    image?: Buffer;
    numero?: string;
    role?: string;
}
