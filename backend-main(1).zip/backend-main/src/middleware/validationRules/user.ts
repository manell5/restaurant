import { FastifySchema } from 'fastify';

const passwordPattern = '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$';

// Validation schema for POST /users/register
export const registerUserSchema: FastifySchema = {
    body: {
        type: 'object',
        required: ['nom', 'prenom', 'email', 'password'],
        properties: {
            nom: { type: 'string', minLength: 1 },
            prenom: { type: 'string', minLength: 1 },
            email: { type: 'string', format: 'email' },
            password: {
                type: 'string',
                minLength: 8,
                pattern: passwordPattern,
            },
            numero: { type: 'string', minLength: 10, maxLength: 10 },
        },
        additionalProperties: false,
    },
};

// Validation schema for POST /users/login
export const loginUserSchema: FastifySchema = {
    body: {
        type: 'object',
        required: ['email', 'password'],
        properties: {
            email: { type: 'string', format: 'email' },
            password: {
                type: 'string',
                minLength: 8,
                pattern: passwordPattern,
            },
        },
        additionalProperties: false,
    },
};

// Validation schema for PUT /users/profile
export const updateUserProfileSchema: FastifySchema = {
    body: {
        type: 'object',
        properties: {
            nom: { type: 'string', minLength: 1 },
            prenom: { type: 'string', minLength: 1 },
            numero: { type: 'string', minLength: 10, maxLength: 10 },
            newPassword: {
                type: 'string',
                minLength: 8,
                pattern: passwordPattern,
            },
            password: {
                type: 'string',
                minLength: 8,
                pattern: passwordPattern,
            },
            oldPassword: { type: 'string', minLength: 8 },
            image: { type: 'string', format: 'binary' },
        },
        minProperties: 1,
    },
};

// Validation schema for PUT /admin/users/:id/role
export const updateUserRoleSchema: FastifySchema = {
    params: {
        type: 'object',
        required: ['id'],
        properties: {
            id: { type: 'string' },
        },
    },
    body: {
        type: 'object',
        required: ['role'],
        properties: {
            role: {
                type: 'string',
                enum: ['admin', 'customer'],
            },
        },
    },
};
