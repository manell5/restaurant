import { FastifySchema } from 'fastify';

// Validation schema for GET /menu/:id
export const getMenuByIdSchema: FastifySchema = {
    params: {
        type: 'object',
        required: ['id'],
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
    },
};

// Validation schema for POST /menu
export const createMenuItemSchema: FastifySchema = {
    body: {
        type: 'object',
        required: ['nom', 'prix', 'description', 'categorie', 'image'],
        properties: {
            nom: { type: 'string', minLength: 1 },
            prix: { type: 'number', minimum: 0 },
            description: { type: 'string', minLength: 1 },
            categorie: { type: 'string', minLength: 1 },
            image: {
                type: 'string',
                minLength: 1,
                pattern:
                    '^data:image\\/(jpeg|png|gif|bmp);base64,[A-Za-z0-9+/=]+$',
            },
        },
    },
};

// Validation schema for PUT /admin/menu/:id
export const updateMenuItemSchema: FastifySchema = {
    body: {
        type: 'object',
        properties: {
            nom: { type: 'string', minLength: 1 },
            prix: { type: 'number', minimum: 0 },
            description: { type: 'string', minLength: 1 },
            categorie: { type: 'string', minLength: 1 },
            image: {
                type: 'string',
                minLength: 1,
                pattern:
                    '^data:image\\/(jpeg|png|gif|bmp);base64,[A-Za-z0-9+/=]+$',
            },
        },
        minProperties: 1,
    },
};

// Validation schema for DELETE /admin/menu/:id
export const deleteMenuItemSchema: FastifySchema = {
    params: {
        type: 'object',
        required: ['id'],
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
    },
};
