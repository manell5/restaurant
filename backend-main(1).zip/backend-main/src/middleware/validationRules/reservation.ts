import { FastifySchema } from 'fastify';

// GET /reservations/:id
export const getReservationByIdSchema: FastifySchema = {
    params: {
        type: 'object',
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
        required: ['id'],
    },
};

// POST /reservations
export const postReservationsSchema: FastifySchema = {
    body: {
        type: 'object',
        properties: {
            number_of_people: { type: 'number', minimum: 1 },
            date: { type: 'string', format: 'date-time' },
        },
        required: ['number_of_people', 'date'],
        additionalProperties: false,
    },
};

// PUT /reservations/:id
export const putReservationSchema: FastifySchema = {
    params: {
        type: 'object',
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
        required: ['id'],
    },
    body: {
        type: 'object',
        properties: {
            number_of_people: { type: 'number', minimum: 1 },
            date: { type: 'string', format: 'date-time' },
        },
        additionalProperties: false,
        minProperties: 1, // At least one field must be present
    },
};

// DELETE /reservations/:id
export const deleteReservationSchema: FastifySchema = {
    params: {
        type: 'object',
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
        required: ['id'],
    },
};
