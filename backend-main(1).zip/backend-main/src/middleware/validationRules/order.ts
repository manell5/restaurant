import { FastifySchema } from 'fastify';

// GET /orders/:id
export const getOrderByIdSchema: FastifySchema = {
    params: {
        type: 'object',
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
        required: ['id'],
    },
};

// POST /orders
export const postOrderSchema: FastifySchema = {
    body: {
        type: 'object',
        properties: {
            product_id: { type: 'string' },
        },
        required: ['product_id'],
        additionalProperties: false,
    },
};

// DELETE /orders/:id
export const deleteOrderSchema: FastifySchema = {
    params: {
        type: 'object',
        properties: {
            id: { type: 'string', format: 'uuid' },
        },
        required: ['id'],
    },
};
