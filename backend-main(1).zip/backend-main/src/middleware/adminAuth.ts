import { FastifyReply, FastifyRequest } from 'fastify';
import { server } from '../server';

// Interface for JWT payload including role
interface JWTUser {
    id: string;
    email: string;
    nom: string;
    prenom: string;
    role: string;
}

export async function verifyAdmin(
    request: FastifyRequest,
    reply: FastifyReply,
) {
    try {
        const user = await request.jwtVerify<JWTUser>();

        if (user.role === 'admin') {
            return;
        }

        const [rows] = (await server.mysql.query(
            'SELECT role FROM users WHERE id = ?',
            [user.id],
        )) as [any[], any];

        if (!rows.length || rows[0].role !== 'admin') {
            return reply.code(403).send({
                status: 403,
                message: 'Access denied. Admin privileges required.',
            });
        }
    } catch (err) {
        return reply.code(401).send({
            status: 401,
            message: 'Authentication required',
        });
    }
}
