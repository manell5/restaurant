import { Product } from '../models/product';
import { server } from '../server';
import { v4 as uuidv4 } from 'uuid';
import * as sharp from 'sharp'; // Add this dependency: npm install sharp
import {
    getMenuByIdSchema,
    createMenuItemSchema,
    updateMenuItemSchema,
    deleteMenuItemSchema,
} from '../middleware/validationRules/menu';
import { verifyAdmin } from '../middleware/adminAuth';

// Image compression helper function
async function compressImage(imageBuffer: string) {
    try {
        if (!imageBuffer) return null;

        // Remove data URL prefix if present and convert to buffer
        const base64Data = imageBuffer.replace(
            /^data:image\/[a-z]+;base64,/,
            '',
        );
        const buffer = Buffer.from(base64Data, 'base64');

        // Check if image is larger than 500KB
        const imageSizeKB = Buffer.byteLength(imageBuffer, 'utf8') / 1024;

        if (imageSizeKB <= 500) {
            // Image is already under 500KB, return original
            return imageBuffer;
        }

        // Image is over 500KB, compress it
        let quality = 85;
        let maxWidth = 1200;
        let maxHeight = 900;
        let compressedBuffer;
        let compressedBase64;
        let compressedSizeKB;

        // Try different compression levels until we get under 500KB
        do {
            compressedBuffer = await sharp(buffer)
                .resize(maxWidth, maxHeight, {
                    fit: 'inside',
                    withoutEnlargement: true,
                })
                .jpeg({ quality })
                .toBuffer();

            compressedBase64 = `data:image/jpeg;base64,${compressedBuffer.toString('base64')}`;
            compressedSizeKB =
                Buffer.byteLength(compressedBase64, 'utf8') / 1024;

            if (compressedSizeKB > 500) {
                // Still too large, reduce quality or dimensions
                if (quality > 20) {
                    quality -= 10;
                } else if (maxWidth > 400) {
                    maxWidth = Math.floor(maxWidth * 0.8);
                    maxHeight = Math.floor(maxHeight * 0.8);
                    quality = 70; // Reset quality when resizing
                } else {
                    // Can't compress further, return what we have
                    break;
                }
            }
        } while (compressedSizeKB > 500 && (quality > 20 || maxWidth > 400));

        server.log.info(
            `Image compressed from ${imageSizeKB.toFixed(2)}KB to ${compressedSizeKB.toFixed(2)}KB`,
        );
        return compressedBase64;
    } catch (error) {
        server.log.error('Image compression failed:', error);
        // Return original image if compression fails
        return imageBuffer;
    }
}

// Helper function to process products with compressed images
async function processProductsWithCompression(products: Product[]) {
    const processedProducts = await Promise.all(
        products.map(async (product) => ({
            ...product,
            image: await compressImage(product.image),
        })),
    );
    return processedProducts;
}

server.get('/menu/recommendations', async function (req, reply) {
    const connect = await server.mysql.getConnection();
    try {
        const [rows, _] = (await connect.query(
            `SELECT p.*
FROM product p
LEFT JOIN (
    SELECT p.id, SUM(o.quantity) AS sum_quantity
    FROM product p
    LEFT JOIN orders o ON p.id = o.product_id
    GROUP BY p.id
    ORDER BY sum_quantity DESC
    LIMIT 4
) AS top_products ON p.id = top_products.id
WHERE top_products.id IS NOT NULL
`,
        )) as [Product[], any];

        // Compress images before sending
        const products = await processProductsWithCompression(rows);

        reply.send({
            status: 200,
            message: 'Retrouved recommendations successfuly.',
            data: products,
        });
    } finally {
        await connect.release();
    }
});

server.get('/menu/search/:query', async function (req, reply) {
    const connect = await server.mysql.getConnection();
    try {
        const { query } = req.params as { query: string };
        const [rows, _] = (await connect.query(
            'SELECT * FROM product WHERE nom LIKE ?',
            [`%${query}%`],
        )) as [Product[], any];
        if (!rows.length) {
            return reply.code(404).send({
                status: 404,
                message: 'No products found',
            });
        }

        // Compress images before sending
        const products = await processProductsWithCompression(rows);

        reply.code(200).send({
            status: 200,
            message: 'Products retrieved successfully',
            data: products,
        });
    } finally {
        await connect.release();
    }
});

server.get('/menu', async function (req, reply) {
    const connect = await server.mysql.getConnection();
    try {
        const [rows, _] = (await connect.query('SELECT * FROM product')) as [
            Product[],
            any,
        ];

        // Compress images before sending
        const products = await processProductsWithCompression(rows);

        reply.code(200).send({
            status: 200,
            message: 'Menu items retrieved successfully',
            data: products,
        });
    } finally {
        await connect.release();
    }
});

server.get('/menu/categorie/:categorie', async function (req, reply) {
    const connect = await server.mysql.getConnection();
    try {
        const { categorie } = req.query as { categorie: string };
        const [rows, _] = (await connect.query(
            'SELECT * FROM product WHERE categorie=?',
            [categorie],
        )) as [Product[], any];
        if (!rows.length) {
            return reply.code(404).send({
                status: 404,
                message: 'No products found in this category',
            });
        }

        // Compress images before sending
        const products = await processProductsWithCompression(rows);

        reply.code(200).send({
            status: 200,
            message: 'Products retrieved successfully',
            data: products,
        });
    } finally {
        await connect.release();
    }
});

server.get(
    '/menu/:id',
    { schema: getMenuByIdSchema },
    async function (req, reply) {
        const connect = await server.mysql.getConnection();
        try {
            const { id } = req.params as { id: string };
            if (!id)
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing product ID',
                });
            const [rows, _] = (await connect.query(
                'SELECT * FROM product WHERE id=?',
                [id],
            )) as [Product[], any];
            if (!rows.length) {
                return reply.code(404).send({
                    status: 404,
                    message: 'Product not found',
                });
            }

            // Compress image before sending
            const products = await processProductsWithCompression(rows);

            reply.code(200).send({
                status: 200,
                message: 'Product retrieved successfully',
                data: products[0],
            });
        } finally {
            await connect.release();
        }
    },
);

// Admin routes with authentication
server.post(
    '/admin/menu',
    {
        schema: createMenuItemSchema,
    },
    async function (req, reply) {
        const connect = await server.mysql.getConnection();
        try {
            const { nom, prix, description, categorie, image } =
                req.body as Omit<Product, 'image'> & { image: string };
            if (!nom || !prix || !description || !categorie || !image)
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing required fields',
                });

            const id = uuidv4();

            // Compress image before storing (optional - you might want to store high quality)
            // For storage, you might want to keep original quality
            // const compressedImage = await compressImage(image, 90, 1200, 900);

            await connect.query(
                'INSERT INTO product (id, nom, prix, description, categorie, image) VALUES (?, ?, ?, ?, ?, ?)',
                [id, nom, prix, description, categorie, image], // Use original or compressedImage
            );
            reply.code(201).send({
                status: 201,
                message: 'Product created successfully',
                data: { id },
            });
        } finally {
            await connect.release();
        }
    },
);

server.put(
    '/admin/menu/:id',
    {
        preHandler: verifyAdmin,
        schema: updateMenuItemSchema,
    },
    async function (req, reply) {
        const connect = await server.mysql.getConnection();
        try {
            const { id } = req.params as { id: string };
            const body = req.body as Partial<Product>;
            if (!id)
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing product ID',
                });
            const keys = Object.keys(body);
            if (!keys.length)
                return reply.code(400).send({
                    status: 400,
                    message: 'No fields to update',
                });

            const updateFields = [];
            const updateValues = [];
            for (const key of Object.keys(body)) {
                if (body[key as keyof Product]) {
                    updateFields.push(key);
                    let value = body[key as keyof Product];

                    // Compress image if it's being updated (optional)
                    // if (key === 'image' && value) {
                    //     value = await compressImage(value, 90, 1200, 900);
                    // }

                    updateValues.push(value);
                }
            }
            const query = `UPDATE product SET ${updateFields.map((field) => `${field}=?`).join(', ')} WHERE id=?`;
            await connect.query(query, [...updateValues, id]);
            reply.code(200).send({
                status: 200,
                message: 'Product updated successfully',
            });
        } finally {
            await connect.release();
        }
    },
);

// Add delete endpoint for admin
server.delete(
    '/admin/menu/:id',
    {
        preHandler: verifyAdmin,
        schema: deleteMenuItemSchema,
    },
    async function (req, reply) {
        const connect = await server.mysql.getConnection();
        try {
            const { id } = req.params as { id: string };
            if (!id)
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing product ID',
                });
            await connect.query('DELETE FROM product WHERE id=?', [id]);
            reply.code(200).send({
                status: 200,
                message: 'Product deleted successfully',
            });
        } finally {
            await connect.release();
        }
    },
);
