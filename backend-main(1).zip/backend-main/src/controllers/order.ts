import { v4 } from 'uuid';
import {
    deleteOrderSchema,
    getOrderByIdSchema,
    postOrderSchema,
} from '../middleware/validationRules/order';
import { Order } from '../models/order';
import { Product } from '../models/product';
import { server } from '../server';

server.get('/orders', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{ id: string }>();
        const [orders] = (await connect.query(
            'SELECT * FROM orders o JOIN product p ON o.product_id = p.id WHERE user_id = ?',
            [user.id],
        )) as [(Order & Product)[], any];
        reply.send({
            status: 200,
            message: 'Orders fetched successfully',
            data: orders,
        });
    } finally {
        await connect.release();
    }
});

server.get('/orders/productsCount', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{ id: string }>();
        const [orders] = (await connect.query(
            `SELECT p.nom as productName, o.quantity
            FROM orders o JOIN product p 
            ON o.product_id = p.product_id 
            WHERE o.user_id = ?`,
            [user.id],
        )) as [{ productName: string; quantity: number }[], any];
        reply.send({
            status: 200,
            message: 'Orders fetched successfully',
            data: orders,
        });
    } finally {
        await connect.release();
    }
});

server.get('/orders/productsCount/:productId', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{ id: string }>();
        const { productId: product_id } = req.params as { productId: string };
        const [orders] = (await connect.query(
            `SELECT p.nom as productName, o.quantity 
            FROM orders o JOIN product p 
            ON o.product_id = p.product_id 
            WHERE o.user_id = ? AND o.product_id = ?`,
            [user.id, product_id],
        )) as [{ productName: string; quantity: number }[], any];
        if (!orders.length) {
            return reply.code(404).send({
                status: 404,
                message: 'Product not found',
            });
        }
        if (orders[0].quantity === 0) {
            return reply.code(404).send({
                status: 404,
                message: 'No orders found for this product',
            });
        }
        reply.send({
            status: 200,
            message: 'Orders fetched successfully',
            data: orders[0],
        });
    } finally {
        await connect.release();
    }
});

server.get(
    '/orders/:id',
    { schema: getOrderByIdSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const user = await req.jwtVerify<{ id: string }>();
            const orderId = (req.params as { id: string }).id;
            const [orders] = (await connect.query(
                'SELECT * FROM orders WHERE id = ?',
                [user.id, orderId],
            )) as [Order[], any];
            if (orders.length === 0) {
                return reply.code(404).send({
                    status: 404,
                    message: 'Order not found',
                });
            }
            if (orders[0].user_id !== user.id) {
                return reply.code(403).send({
                    status: 403,
                    message: 'You do not have permission to access this order',
                });
            }
            reply.send({
                status: 200,
                message: 'Orders fetched successfully',
                data: orders[0],
            });
        } finally {
            await connect.release();
        }
    },
);

server.post('/orders', { schema: postOrderSchema }, async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{ id: string }>();
        const { product_id } = req.body as { product_id: string };
        // Check if product exists
        const [products] = (await connect.query(
            'SELECT * FROM product WHERE id=?',
            [product_id],
        )) as [Product[], any];
        if (!products.length) {
            return reply.code(404).send({
                status: 404,
                message: 'Product not found',
            });
        }
        const [orders] = (await connect.query(
            'SELECT * FROM orders WHERE user_id=? AND product_id=?',
            [user.id, product_id],
        )) as [Order[], any];
        // Insert order into database
        if (!orders.length) {
            const id = v4();
            await connect.query(
                'INSERT INTO orders (id, user_id, product_id, quantity) VALUES (?, ?, ?, ?)',
                [id, user.id, product_id, 1],
            );
        } else {
            await connect.query(
                'UPDATE orders SET quantity = ? WHERE user_id = ? AND product_id = ?',
                [orders[0].quantity + 1, user.id, product_id],
            );
        }
        reply.code(200).send({
            status: 200,
            message: 'Order created successfully',
        });
    } finally {
        await connect.release();
    }
});

server.delete(
    '/orders/:id',
    { schema: deleteOrderSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const user = await req.jwtVerify<{ id: string }>();
            const orderId = (req.params as { id: string }).id;
            const [orders] = (await connect.query(
                'SELECT * FROM orders WHERE id=?',
                [orderId],
            )) as [Order[], any];
            if (!orders.length) {
                return reply.code(404).send({
                    status: 404,
                    message: 'Order not found',
                });
            }
            if (orders[0].user_id !== user.id) {
                return reply.code(403).send({
                    status: 403,
                    message: 'You do not have permission to delete this order',
                });
            }
            await connect.query('DELETE FROM orders WHERE id=?', [orderId]);
            reply.send({
                status: 200,
                message: 'Order deleted successfully',
            });
        } finally {
            await connect.release();
        }
    },
);
