import { User } from '../models/user.js';
import { server } from '../server.js';
import * as bcrypt from 'bcrypt';
import { createHash } from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import {
    registerUserSchema,
    loginUserSchema,
    updateUserProfileSchema,
    updateUserRoleSchema,
} from '../middleware/validationRules/user';
import { verifyAdmin } from '../middleware/adminAuth';
import { Order } from '../models/order.js';
import { Product } from '../models/product.js';

server.post(
    '/users/register',
    { schema: registerUserSchema },
    async function (req, reply) {
        const connect = await server.mysql.getConnection();
        try {
            const body = req.body as {
                nom: string;
                prenom: string;
                email: string;
                password: string;
                numero: string;
            };
            if (!body.nom || !body.prenom || !body.email || !body.password) {
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing required fields',
                });
            } else {
                const [rows, _] = (await connect.query(
                    'SELECT * FROM users WHERE email=?',
                    [body.email],
                )) as [User[], any];
                if (rows.length) {
                    return reply.code(409).send({
                        status: 409,
                        message: 'User with that email already exists',
                    });
                }
                const sha256Password = createHash('sha256')
                    .update(body.password)
                    .digest('hex');
                const hashedPassword = await bcrypt.hash(sha256Password, 10);
                const userId = uuidv4();
                connect.query(
                    'INSERT INTO users(id, nom, prenom, email, password, role, numero) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [
                        userId,
                        body.nom,
                        body.prenom,
                        body.email,
                        hashedPassword,
                        'customer',
                        body.numero,
                    ],
                );
                reply.code(200).send({
                    status: 200,
                    message: 'User registered successfully',
                    data: { id: userId },
                });
            }
        } finally {
            await connect.release();
        }
    },
);

server.post('/users/login', { schema: loginUserSchema }, async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const body = req.body as { email: string; password: string };
        if (!body.email || !body.password)
            return reply.code(400).send({
                status: 400,
                message: 'Missing required fields',
            });
        const [rows, _] = (await connect.query(
            'SELECT * FROM users WHERE email=?',
            [body.email],
        )) as [User[], any];
        if (!(rows as User[]).length)
            return reply.code(401).send({
                status: 401,
                message: 'Invalid email or password',
            });
        const user = rows[0];
        const sha256Password = createHash('sha256')
            .update(body.password)
            .digest('hex');
        const isPasswordValid = await bcrypt.compare(
            sha256Password,
            user.password,
        );
        if (!isPasswordValid)
            return reply.code(401).send({
                status: 401,
                message: 'Invalid email or password',
            });
        const token = server.jwt.sign({ id: user.id }, { expiresIn: '6h' });
        reply.code(200).send({
            status: 200,
            message: 'Login successful',
            data: { token },
        });
    } finally {
        await connect.release();
    }
});

server.get('/users/profile', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const { id } = await req.jwtVerify<{ id: string }>();
        const [user] = (await connect.query('SELECT * FROM users WHERE id=?', [
            id,
        ])) as [User[], any];
        if (!user.length) {
            return reply.code(404).send({
                status: 404,
                message: 'User not found',
            });
        }
        const { password, ...userData } = user[0];
        reply.code(200).send({
            status: 200,
            message: 'Profile retrieved successfully',
            data: {
                ...userData,
                image: user[0].image ? user[0].image.toString() : null,
            },
        });
    } finally {
        await connect.release();
    }
});

server.put(
    '/users/profile',
    { schema: updateUserProfileSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const user = await req.jwtVerify<{ id: string }>();
            const body = req.body as Partial<
                Omit<User, 'id' | 'role' | 'password' | 'email'> & {
                    newPassword: string;
                    oldPassword: string;
                }
            >;
            let query = 'UPDATE users SET ';
            const params = [];
            if (body.image) {
                const url = body.image.toString();
                const base64Data = url.replace(/^data:image\/\w+;base64,/, '');
                params.push(base64Data);
                query += 'image=?, ';
            }
            if (body.nom) {
                params.push(body.nom);
                query += 'nom=?, ';
            }
            if (body.prenom) {
                params.push(body.prenom);
                query += 'prenom=?, ';
            }
            if (body.numero) {
                params.push(body.numero);
                query += 'numero=?, ';
            }
            if (body.newPassword) {
                if (!body.oldPassword) {
                    return reply.code(400).send({
                        status: 400,
                        message:
                            'Old password is required to change the password',
                    });
                }
                const oldPassword = createHash('sha256')
                    .update(body.oldPassword)
                    .digest('hex');
                const [users] = (await connect.query(
                    'SELECT * FROM users WHERE id=?',
                    [user.id],
                )) as [User[], any];
                if (!(await bcrypt.compare(oldPassword, users[0].password))) {
                    return reply.code(401).send({
                        status: 401,
                        message: 'Invalid password',
                    });
                }
                const sha256Password = createHash('sha256')
                    .update(body.newPassword)
                    .digest('hex');
                const hashedPassword = await bcrypt.hash(sha256Password, 10);
                params.push(hashedPassword);
                query += 'password=?, ';
            }
            if (params.length === 0) {
                return reply.code(400).send({
                    status: 400,
                    message: 'No fields to update',
                });
            }
            params.push(user.id);
            query = query.slice(0, -2);
            query += ' WHERE id=?';
            await connect.query(query, params);
            reply.code(200).send({
                status: 200,
                message: 'Profile updated successfully',
            });
        } finally {
            await connect.release();
        }
    },
);

server.delete('/users/profile', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{ id: string }>();
        await connect.query('DELETE FROM users WHERE id=?', [user.id]);
        reply.code(200).send({
            status: 200,
            message: 'Account deleted successfully',
        });
    } finally {
        await connect.release();
    }
});

server.put(
    '/admin/users/:id/role',
    { preHandler: verifyAdmin, schema: updateUserRoleSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const { id } = req.params as { id: string };
            const { role } = req.body as { role: string };
            if (!id)
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing user ID',
                });
            if (!role)
                return reply.code(400).send({
                    status: 400,
                    message: 'Missing role value',
                });
            // Check if valid role (you can extend this validation as needed)
            if (!['admin', 'customer'].includes(role)) {
                return reply.code(400).send({
                    status: 400,
                    message: 'Invalid role. Must be "admin" or "customer"',
                });
            }
            // Check if user exists
            const [users] = (await connect.query(
                'SELECT * FROM users WHERE id=?',
                [id],
            )) as [User[], any];
            if (!users.length) {
                return reply.code(404).send({
                    status: 404,
                    message: 'User not found',
                });
            }
            // Update the role
            await connect.query('UPDATE users SET role=? WHERE id=?', [
                role,
                id,
            ]);
            reply.code(200).send({
                status: 200,
                message: 'User role updated successfully',
            });
        } finally {
            await connect.release();
        }
    },
);

server.get('/users/orderedProducts', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{
            id: string;
        }>();
        const [products] = (await connect.query(
            'SELECT * FROM orders o RIGHT JOIN product p ON o.product_id = p.product_id WHERE o.user_id = ?',
            [user.id],
        )) as [(Order & Product)[], any];
        reply.send({
            status: 200,
            message: 'Products fetched successfully',
            data: products,
        });
    } finally {
        await connect.release();
    }
});
