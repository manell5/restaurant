import {
    deleteReservationSchema,
    getReservationByIdSchema,
    postReservationsSchema,
    putReservationSchema,
} from '../middleware/validationRules/reservation';
import { Reservation } from '../models/reservation';
import { server } from '../server';

server.get('/reservations', async (req, reply) => {
    const connect = await server.mysql.getConnection();
    try {
        const user = await req.jwtVerify<{
            id: string;
        }>();
        const [reservations] = (await connect.query(
            'SELECT * FROM reservations WHERE user_id = ?',
            [user.id],
        )) as [Reservation[], any];
        reply.send({
            status: 200,
            message: 'Reservations fetched successfully',
            data: reservations,
        });
    } finally {
        await connect.release();
    }
});

server.get(
    '/reservations/:id',
    { schema: getReservationByIdSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const user = await req.jwtVerify<{
                id: string;
            }>();

            const reservationId = (req.params as { id: string }).id;

            const [reservations] = (await connect.query(
                'SELECT * FROM reservations WHERE id = ?',
                [user.id, reservationId],
            )) as [Reservation[], any];

            if (reservations.length === 0) {
                return reply.code(404).send({
                    status: 404,
                    message: 'Reservation not found',
                });
            }

            if (reservations[0].user_id !== user.id) {
                return reply.code(403).send({
                    status: 403,
                    message:
                        'You do not have permission to access this reservation',
                });
            }

            reply.send({
                status: 200,
                message: 'Reservations fetched successfully',
                data: reservations[0],
            });
        } finally {
            await connect.release();
        }
    },
);

server.post(
    '/reservations',
    { schema: postReservationsSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const user = await req.jwtVerify<{
                id: string;
            }>();
            const reservation: Omit<Reservation, 'user_id'> =
                req.body as Reservation;
            await connect.query(
                'INSERT INTO reservations (number_of_people, date, user_id) VALUES (?, ?, ?)',
                [reservation.number_of_people, reservation.date, user.id],
            );
            reply.send({
                status: 200,
                message: 'Reservation created successfully',
            });
        } catch (e) {
            console.error(e);
            reply.code(500).send({
                status: 500,
                message: 'Error creating reservation',
            });
        } finally {
            await connect.release();
        }
    },
);
server.put(
    '/reservations/:id',
    { schema: putReservationSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const User = await req.jwtVerify<{ id: string }>();
            const reservationId = (req.params as { id: string }).id;
            const reservation: Partial<Omit<Reservation, 'user_id'>> =
                req.body as Reservation;
            const [res] = (await connect.query(
                'SELECT * FROM reservations WHERE id = ? AND user_id = ?',
                [reservationId, User.id],
            )) as [Reservation[], any];
            if (res.length === 0) {
                return reply.code(404).send({
                    status: 404,
                    message: 'Reservation not found',
                });
            }

            let query = 'UPDATE reservations SET ';
            const params = [];
            if (reservation.number_of_people) {
                query += 'number_of_people = ?, ';
                params.push(reservation.number_of_people);
            }
            if (reservation.date) {
                query += 'date = ?, ';
                params.push(reservation.date);
            }
            query = query.slice(0, -2);
            query += ' WHERE id = ? AND user_id = ?';
            params.push(reservationId, User.id);

            await connect.query(query, params);
            reply.send({
                status: 200,
                message: 'Reservation updated successfully',
            });
        } catch (e) {
            console.error(e);
            reply.code(500).send({
                status: 500,
                message: 'Error updating reservation',
            });
        } finally {
            await connect.release();
        }
    },
);

server.delete(
    '/reservations/:id',
    { schema: deleteReservationSchema },
    async (req, reply) => {
        const connect = await server.mysql.getConnection();
        try {
            const user = await req.jwtVerify<{ id: string }>();
            const reservationId = (req.params as { id: string }).id;
            const [res] = (await connect.query(
                'SELECT * FROM reservations WHERE id = ? AND user_id = ?',
                [reservationId, user.id],
            )) as [Reservation[], any];
            if (res.length === 0) {
                return reply.code(404).send({
                    status: 404,
                    message: 'Reservation not found',
                });
            }
            await connect.query('DELETE FROM reservations WHERE id = ?', [
                reservationId,
            ]);
            reply.send({
                status: 200,
                message: 'Reservation deleted successfully',
            });
        } catch (e) {
            console.error(e);
            reply.code(500).send({
                status: 500,
                message: 'Error deleting reservation',
            });
        } finally {
            await connect.release();
        }
    },
);
