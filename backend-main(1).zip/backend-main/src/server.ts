import mysql, {
    MySQLPromiseConnection,
    MySQLPromisePool,
} from '@fastify/mysql';
import Fastify, { FastifyInstance } from 'fastify';
import fastifyJwt from 'fastify-jwt';

import * as dotenv from 'dotenv';

import cors from '@fastify/cors';

dotenv.config();

//@ts-ignore
export const server: FastifyInstance & { mysql: MySQLPromisePool } = Fastify(
    {},
);

server.register(cors, {
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
});

server.register(mysql, {
    host: process.env.MYSQL_HOST!,
    user: process.env.MYSQL_USER!,
    password: process.env.MYSQL_PASSWORD!,
    database: process.env.MYSQL_DATABASE!,
    promise: true,
    connectionLimit: 10,

    // Additional pool options
    pool: {
        min: 0,
        max: 10,
        acquireTimeoutMillis: 60000,
        createTimeoutMillis: 30000,
        destroyTimeoutMillis: 5000,
        idleTimeoutMillis: 30000,
        reapIntervalMillis: 1000,
        createRetryIntervalMillis: 200,
    },
});

server.register(fastifyJwt, {
    secret: process.env.JWT_SECRET!,
});
