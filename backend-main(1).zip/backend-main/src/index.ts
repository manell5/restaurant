import { server } from './server.js';

import importDirectory from './helpers/loader.js';
import * as dotenv from 'dotenv';

dotenv.config();

const start = async () => {
    // Load all controllers
    await importDirectory('dist/controllers');
    try {
        await server.listen({ port: 3000, host: '0.0.0.0' });
        const address = server.server.address();
        const port = typeof address === 'string' ? address : address?.port;

        console.log(`listening on http://localhost:${port}`);
    } catch (err) {
        throw err;
    }
};

start();
